package utils

type LLBConfig struct {
	DbName    string
	DbHost    string
	DbUser    string
	DbPass    string
	BadgerDir string
}
